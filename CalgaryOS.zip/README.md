# CalgaryOS
This one uses UserControl instead of windows
